import subprocess
import ctypes

def run_as_admin(command):
    try:
        ctypes.windll.shell32.ShellExecuteW(None, "runas", command, None, None, 1)
    except Exception as e:
        print(e)

# Disable USB ports
run_as_admin("reg add HKLM\\SYSTEM\\CurrentControlSet\\Services\\USBSTOR /v Start /t REG_DWORD /d 4 /f")

# Disable Bluetooth
run_as_admin("reg add HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\RasMan /v AllowBluetooth /t REG_DWORD /d 0 /f")
import subprocess

# Disable Command Prompt
subprocess.run("reg add HKCU\Software\Policies\Microsoft\Windows\System /v DisableCMD /t REG_DWORD /d 1 /f", shell=True)
# Add website entry to hosts file to block access
website_entry = "127.0.0.1 facebook.com"
hosts_path = r"C:\Windows\System32\drivers\etc\hosts"

with open(hosts_path, "a") as hosts_file:
    hosts_file.write(website_entry + "\n")
